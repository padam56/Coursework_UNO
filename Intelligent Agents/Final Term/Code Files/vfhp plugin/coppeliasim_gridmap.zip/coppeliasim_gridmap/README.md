# coppeliasim_gridmap
CoppeliaSim GridMap plugin
