Here we want to apply logistic regression on the cancer dataset.

File X.txt => Column(1st, 2nd, 3rd) => (1, Size_of_Tumor, Age_of_Tumor)
File Y.txt => True Responsed, 0=>Benign and 1=> Malignant. 

Note: W is a N � N diagonal matrix